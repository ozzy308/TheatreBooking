package com.example.theatre;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.activity_theatre.xml.R;

import java.util.ArrayList;

public class theatre extends AppCompatActivity {
    ArrayList<details> Performancelist;
    adapter adapterObj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_performtheatre);
    }
    public void list (View view){
        Performancelist= new ArrayList<>();
        Performancelist.add(new details("The Merchant of Venice", "Play by william shakespeare", "April 23rd", 8, true, true));
        Performancelist.add(new details("Hamlet", "Play by Shakespeare", "May 19", 6, false, false));
        Performancelist.add(new details("A Midsummer Night's Dream", "Play by Shakespeare", "June 3", 7, true, false));
        Performancelist.add(new details("Oedipus the King", "Play by Sophocles", "July 28", 8, true, true));
        Performancelist.add(new details("The Tempest", "Play by Shakespeare", "August 19", 2, true, true));
        Performancelist.add(new details("Antigone", "Play by Sophocles", "September 20", 9, false, true));

        RecyclerView recyclerObj = findViewById(R.id.recycler);
        recyclerObj.setLayoutManager(new LinearLayoutManager(this));
        adapterObj = new adapter(this, Performancelist);
        recyclerObj.setAdapter(adapterObj);

    }
}
