package com.example.theatre;

public class newuserlist {
    String name, username, password;

    public String getName(){
        return name;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
}
