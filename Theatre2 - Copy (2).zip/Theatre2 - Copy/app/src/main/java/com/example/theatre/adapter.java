package com.example.theatre;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.activity_theatre.xml.R;

import java.util.List;

public class adapter extends RecyclerView.Adapter<adapter.ViewHolder> {
    private List<details> Data;
    private LayoutInflater inflater;
    Context context;

    public adapter(Context context, List<details> datamore){
        Data = datamore;
        this.inflater = LayoutInflater.from(context);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.row2, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adapter.ViewHolder holder, int position) {
        String name = Data.get(position).getTitle();
        holder.titleview.setText(name);
        String description = Data.get(position).getDescription();
        holder.descriptionview.setText(description);
        String date = Data.get(position).getDate();
        holder.dateview.setText(date);
        Integer time = Data.get(position).getTime();
        holder.timeview.setText(time);
        boolean wheelchairAccess = Data.get(position).getWheelchairAccess();
        boolean epilepsy = Data.get(position).getEpilepsy();

        holder.itemView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(context,performancedetails.class);
                intent.putExtra("Title names", name);
                intent.putExtra("Description", description);
                intent.putExtra("Date", date);
                intent.putExtra("Time", time);
                intent.putExtra("Epilepsy", epilepsy);
                intent.putExtra("Wheelchair access", wheelchairAccess);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return Data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleview, descriptionview, dateview, timeview;
        public ViewHolder(View view){
            super(view);
            titleview = itemView.findViewById(R.id.titletext);
            descriptionview = itemView.findViewById(R.id.descriptiontext);
            timeview = itemView.findViewById(R.id.timetext);
            dateview = itemView.findViewById(R.id.datetext);

        }
    }
}
