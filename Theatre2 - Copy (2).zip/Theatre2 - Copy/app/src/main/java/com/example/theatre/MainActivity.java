package com.example.theatre;

import static android.text.TextUtils.isEmpty;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.activity_theatre.xml.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button login;
    Button register;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.usernameTxt);
        password = findViewById(R.id.passwordTxt);
        register = findViewById(R.id.registerbutton);
        login = findViewById(R.id.LoginButton);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(this, Register.class);
                startActivity(intent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkLogin();
            }
        });


    private void checkLogin() {
        if (isEmpty(username)) {
            username.setError("You need to input a username");
        }
        if (isEmpty(password)) {
            password.setError("You need to input a password");
        }
    }
        public void onClick(View view){
            String username = String.valueOf(username.getText());
            String password = String.valueOf(password.getText());
            if (username.getText().toString().equals("admin") && password.getText().toString().equals("password")) {
                Intent intent = new Intent(this, theatre.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Login unsuccessful", Toast.LENGTH_LONG).show();
            }
        }
        public void register(View view){
            Intent intent = new Intent(this, Register.class);
            startActivity(intent);
        }
    }
}

